**Nombre**: Espinoza Huaman, Diego Alexhander  
**Código**: 22140106

# IMPORTANTE

## Librerías Usadas

Asegúrate de instalar las siguientes librerías para ejecutar el proyecto:

```bash
pip install numpy
pip install plotly
pip install scipy
pip install dash
```

## GitHub

Puedes seguir el avance del proyecto en el siguiente enlace:
[Visita mi GitHub](https://github.com/diegoAEspinoza/ModelInterface.git)